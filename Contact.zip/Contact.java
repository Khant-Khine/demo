package com.acme.plan;
/**
 *This is package class.It contains Strings for First Name, Last Name, Email and
 *Phone. Also includes address of Address class to store the address.
 * 
 * @author Khant Khine
 */
public class Contact {
    
    private String firstName;
    private String lastName;
    private Address address;
    private String email;
    private String phone;
    
    //Constructor for Contact
    public Contact(){
        firstName="";
        lastName="";
        address=new Address();
        phone="";
    }
    
    //Overloaded Constructor for Contact
    public Contact(String fn, String ln, Address addr, String emal, String ph){
        
        firstName=fn;
        lastName=ln;
        address=addr;
        email=emal;
        phone=ph;
    }
    
    //Getter for First Name
    public String getFirstName(){
        return firstName;
    }
    
    //Getter for Last Name
    public String getLastName(){
        return lastName;
    }
    
    //Getter for Address
    public Address getAddress(){
        return address;
    }
    
    //Getter for Email
    public String getEmail(){
        return email;
    }
    
    //Getter for Phone
    public String getPhone(){
        return phone;
    }
    
    //Setter for First Name
    public void setFirstName(String fn){
        firstName=fn;
    }
    
    //Setter for Last Name
    public void setLastName(String ln){
        lastName=ln;
    }
    
    //Setter for Address
    public void setAddress(Address addr){
        address=addr;
    }
    
    //Setter for Email
    public void setEmail(String emal){
        email=emal;
    }
    
    //Setter for Phone
    public void setPhone(String ph){
        phone=ph;
    }
    
    //toString for String of Contact
    @Override
    public String toString(){
      return(firstName+" "+lastName+"\n"+address.toString()+"\n"+email+"\n"+phone);
    }         
}
