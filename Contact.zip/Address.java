package com.acme.plan;
/**
 *This is an Address class.It contains Strings for Street, and City. 
 *Also includes enum State state, and integer zip.
 * @author Khant Khine
 */
public class Address {
    
    private String street;
    private String city;
    private State state;
    private int zip;
    
    //Constructor for Address
    public Address(){
        street="";
        city="";
        state=State.NONE;
        zip=0;
    }
    
    //Overloaded Constructor for Address
    public Address(String str, String cit, State stat, int zi){
        street=str;
        city=cit;
        state=stat;
        zip=zi;
    }
    
    //Getter for Street
    public String getStreet(){
        return street;
    }
    
    //Getter for City
    public String getCity(){
        return city;
    }
        
    //Getter for State
    public State getState(){
        return state;
    }
    
    //Getter for Zip
    public int getZip(){
        return zip;
    }
    
    //Setter for Street
    public void setStreet(String str){
        street=str;
    }
    
    //Setter for City
    public void setCity(String cit){
        city=cit;
    }
    
    //Setter for State
    public void setState(State stat){
        state=stat;
    }
    
    //Setter for Zip
    public void setZip(int zi){
        zip=zi;
    }
    
    //toString for String of Address
    @Override
    public String toString(){
        return(street+"\n"+city+", "+state+"\n"+zip);
    }
    
}
