package com.acme.plan;

/**
 *This is for enum State.
 * @author Khant Khine
 */

//This is an enum for state to hold the qualifying states.
public enum State{
    AL,
    GA,
    FL,
    TN,
    MS,
    NONE
}
